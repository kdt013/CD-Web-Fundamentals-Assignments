console.log("hello");

var neil = 9;
function neilIncrease(){
    var spanTag = document.querySelector("#neil");

    neil++;
    console.log(neil);

    spanTag.innerText = neil;
}

var nichole = 12;
function nicholeIncrease(){
    var spanTag = document.querySelector("#nichole");

    nichole++;
    console.log(nichole);

    spanTag.innerText = nichole;
}

var jim = 9;
function jimIncrease(){
    var spanTag = document.querySelector("#jim");

    jim++;
    console.log(jim);

    spanTag.innerText = jim;
}



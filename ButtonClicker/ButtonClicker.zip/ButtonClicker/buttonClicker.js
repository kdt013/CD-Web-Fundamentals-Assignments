function clicked(element){
    element.innerText = "Logout";
}

function def(element){
var def=document.querySelector(".add-def");

    def.remove();
}


